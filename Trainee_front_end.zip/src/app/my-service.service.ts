import { Injectable } from '@angular/core';
import {HttpClient,HttpHeaders} from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class MyServiceService {
  up: Trainee;
  constructor(private ser:HttpClient) { }
  public getTr(){
    console.log("ins service get employees");
    const headers=new HttpHeaders().set('Content_Type','text/plain ;charset=utf-8');
    return this.ser.get<Trainee>("http://localhost:8989/tr/getall");
  }

  public addEmp(addemp: Trainee) {
    console.log("ins service add");
    console.log(addemp);
    const headers =new HttpHeaders().set('Content_Type', 'text/plain ;charset=utf-8');
    return this.ser.post("http://localhost:8989/tr/add", addemp,  { headers, responseType: 'text'});
  }

  public update(up: Trainee) {
    this.up = up;
  }
  public updateMethod() {
    return this.up;
  }
  public onUpdate(updatemp: Trainee) {
    console.log("ins service update");
    const headers =new HttpHeaders().set('Content_Type', 'text/plain ;charset=utf-8');
    return this.ser.put("http://localhost:8989/tr/upt", updatemp,  { headers, responseType: 'text'});
  }
  delete(id: number) {
    console.log("ins service delete");
    const headers =new HttpHeaders().set('Content_Type', 'text/plain ;charset=utf-8');
    return this.ser.delete("http://localhost:8989/tr/del/" + id,  { headers, responseType: 'text'});
  }
}
export class Trainee{
  id:number;
  name:string;
  location:string;
  domain:string;
}
