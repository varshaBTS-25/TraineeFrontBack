import { Component, OnInit } from '@angular/core';
import { MyServiceService,Trainee } from '../my-service.service';
import { Router} from '@angular/router';
@Component({
  selector: 'app-add',
  templateUrl: './add.component.html',
  styleUrls: ['./add.component.css']
})
export class AddComponent implements OnInit {
  msg:string;
  constructor(private myservice: MyServiceService,private router:Router) { }

  ngOnInit(): void {
  }
  onSubmit(addemp:Trainee):any{
    console.log(addemp);
     this.myservice.addEmp(addemp).subscribe(data => {
      this.msg=data});
      this.router.navigate(['app-view']);
  }
}
