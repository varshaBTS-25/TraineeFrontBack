import { Component, OnInit } from '@angular/core';
import { MyServiceService,Trainee } from '../my-service.service';
import { Router} from '@angular/router';
@Component({
  selector: 'app-view',
  templateUrl: './view.component.html',
  styleUrls: ['./view.component.css']
})
export class ViewComponent implements OnInit {
  msg:string;
  tr:Trainee[];
  constructor(private ser:MyServiceService,private router:Router) { }
  
  ngOnInit(): any {
    console.log("inside init");
    this.ser.getTr().subscribe(
      response=>this.handleSuccessfulResponse(response),
    );
  }
  handleSuccessfulResponse(response) {
    this.tr = response;
  }
  update(updateemployee: Trainee) {
    this.ser.update(updateemployee);
    this.router.navigate(['app-update']); //updating the employee
  }
  delete(deleteemployee: Trainee): any {
    this.ser.delete(deleteemployee.id).subscribe(data => {
      this.msg = data
    });
    this.router.navigate(['app-view']);
  }
}
