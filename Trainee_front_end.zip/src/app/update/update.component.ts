import { Component, OnInit } from '@angular/core';
import { MyServiceService,Trainee } from '../my-service.service';
import { Router} from '@angular/router';
@Component({
  selector: 'app-update',
  templateUrl: './update.component.html',
  styleUrls: ['./update.component.css']
})
export class UpdateComponent implements OnInit {
  obj1:any;
  tr:Trainee[];
  msg:string;
  constructor(private ser:MyServiceService,private router:Router) {
    this.obj1=this.ser.updateMethod();
   }
   onUpdate(uemployee: Trainee): any {
    return this.ser.onUpdate(uemployee).subscribe(data => {
      this.msg = data
    });
    this.router.navigate(['app-view']);
  }
  ngOnInit(): void {
  }

}
